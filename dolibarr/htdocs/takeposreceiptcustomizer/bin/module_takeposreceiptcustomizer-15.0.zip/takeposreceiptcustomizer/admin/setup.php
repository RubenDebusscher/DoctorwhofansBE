<?php
/* Copyright (C) 2004-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2022 SuperAdmin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    takeposreceiptcustomizer/admin/setup.php
 * \ingroup takeposreceiptcustomizer
 * \brief   TakeposReceiptCustomizer setup page.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

global $langs, $user;

// Libraries
require_once DOL_DOCUMENT_ROOT."/core/lib/admin.lib.php";
require_once '../lib/takeposreceiptcustomizer.lib.php';
//require_once "../class/myclass.class.php";

// Translations
$langs->loadLangs(array("admin", "takeposreceiptcustomizer@takeposreceiptcustomizer"));

// Initialize technical object to manage hooks of page. Note that conf->hooks_modules contains array of hook context
$hookmanager->initHooks(array('takeposreceiptcustomizersetup', 'globalsetup'));

// Access control
if (!$user->admin) {
	accessforbidden();
}

// Parameters
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');
$modulepart = GETPOST('modulepart', 'aZ09');	// Used by actions_setmoduleoptions.inc.php

$value = GETPOST('value', 'alpha');
$label = GETPOST('label', 'alpha');
$scandir = GETPOST('scan_dir', 'alpha');
$type = 'myobject';

$arrayofparameters = array(
	'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM1'=>array('type'=>'string', 'css'=>'minwidth500' ,'enabled'=>1),
	'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM2'=>array('type'=>'textarea','enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM3'=>array('type'=>'category:'.Categorie::TYPE_CUSTOMER, 'enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM4'=>array('type'=>'emailtemplate:thirdparty', 'enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM5'=>array('type'=>'yesno', 'enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM5'=>array('type'=>'thirdparty_type', 'enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM6'=>array('type'=>'securekey', 'enabled'=>1),
	//'TAKEPOSRECEIPTCUSTOMIZER_MYPARAM7'=>array('type'=>'product', 'enabled'=>1),
);

$error = 0;
$setupnotempty = 0;

// Set this to 1 to use the factory to manage constants. Warning, the generated module will be compatible with version v15+ only
$useFormSetup = 0;
// Convert arrayofparameter into a formSetup object
if ($useFormSetup && (float) DOL_VERSION >= 15) {
	require_once DOL_DOCUMENT_ROOT.'/core/class/html.formsetup.class.php';
	$formSetup = new FormSetup($db);

	// you can use the param convertor
	$formSetup->addItemsFromParamsArray($arrayofparameters);

	// or use the new system see exemple as follow (or use both because you can ;-) )

	/*
	// Hôte
	$item = $formSetup->newItem('NO_PARAM_JUST_TEXT');
	$item->fieldOverride = (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST'];
	$item->cssClass = 'minwidth500';

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM1 as a simple string input
	$item = $formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM1');

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM1 as a simple textarea input but we replace the text of field title
	$item = $formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM2');
	$item->nameText = $item->getNameText().' more html text ';

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM3
	$item = $formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM3');
	$item->setAsThirdpartyType();

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM4 : exemple of quick define write style
	$formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM4')->setAsYesNo();

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM5
	$formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM5')->setAsEmailTemplate('thirdparty');

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM6
	$formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM6')->setAsSecureKey()->enabled = 0; // disabled

	// Setup conf TAKEPOSRECEIPTCUSTOMIZER_MYPARAM7
	$formSetup->newItem('TAKEPOSRECEIPTCUSTOMIZER_MYPARAM7')->setAsProduct();
	*/

	$setupnotempty = count($formSetup->items);
}


$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);


/*
 * Actions
 */

include DOL_DOCUMENT_ROOT.'/core/actions_setmoduleoptions.inc.php';

if ($action == 'updateMask') {
	$maskconst = GETPOST('maskconst', 'alpha');
	$maskvalue = GETPOST('maskvalue', 'alpha');

	if ($maskconst) {
		$res = dolibarr_set_const($db, $maskconst, $maskvalue, 'chaine', 0, '', $conf->entity);
		if (!($res > 0)) {
			$error++;
		}
	}

	if (!$error) {
		setEventMessages($langs->trans("SetupSaved"), null, 'mesgs');
	} else {
		setEventMessages($langs->trans("Error"), null, 'errors');
	}
} elseif ($action == 'specimen') {
	$modele = GETPOST('module', 'alpha');
	$tmpobjectkey = GETPOST('object');

	$tmpobject = new $tmpobjectkey($db);
	$tmpobject->initAsSpecimen();

	// Search template files
	$file = ''; $classname = ''; $filefound = 0;
	$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
	foreach ($dirmodels as $reldir) {
		$file = dol_buildpath($reldir."core/modules/takeposreceiptcustomizer/doc/pdf_".$modele."_".strtolower($tmpobjectkey).".modules.php", 0);
		if (file_exists($file)) {
			$filefound = 1;
			$classname = "pdf_".$modele."_".strtolower($tmpobjectkey);
			break;
		}
	}

	if ($filefound) {
		require_once $file;

		$module = new $classname($db);

		if ($module->write_file($tmpobject, $langs) > 0) {
			header("Location: ".DOL_URL_ROOT."/document.php?modulepart=takeposreceiptcustomizer-".strtolower($tmpobjectkey)."&file=SPECIMEN.pdf");
			return;
		} else {
			setEventMessages($module->error, null, 'errors');
			dol_syslog($module->error, LOG_ERR);
		}
	} else {
		setEventMessages($langs->trans("ErrorModuleNotFound"), null, 'errors');
		dol_syslog($langs->trans("ErrorModuleNotFound"), LOG_ERR);
	}
} elseif ($action == 'setmod') {
	// TODO Check if numbering module chosen can be activated by calling method canBeActivated
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'TAKEPOSRECEIPTCUSTOMIZER_'.strtoupper($tmpobjectkey)."_ADDON";
		dolibarr_set_const($db, $constforval, $value, 'chaine', 0, '', $conf->entity);
	}
} elseif ($action == 'set') {
	// Activate a model
	$ret = addDocumentModel($value, $type, $label, $scandir);
} elseif ($action == 'del') {
	$ret = delDocumentModel($value, $type);
	if ($ret > 0) {
		$tmpobjectkey = GETPOST('object');
		if (!empty($tmpobjectkey)) {
			$constforval = 'TAKEPOSRECEIPTCUSTOMIZER_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
			if ($conf->global->$constforval == "$value") {
				dolibarr_del_const($db, $constforval, $conf->entity);
			}
		}
	}
} elseif ($action == 'setdoc') {
	// Set or unset default model
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'TAKEPOSRECEIPTCUSTOMIZER_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
		if (dolibarr_set_const($db, $constforval, $value, 'chaine', 0, '', $conf->entity)) {
			// The constant that was read before the new set
			// We therefore requires a variable to have a coherent view
			$conf->global->$constforval = $value;
		}

		// We disable/enable the document template (into llx_document_model table)
		$ret = delDocumentModel($value, $type);
		if ($ret > 0) {
			$ret = addDocumentModel($value, $type, $label, $scandir);
		}
	}
} elseif ($action == 'unsetdoc') {
	$tmpobjectkey = GETPOST('object');
	if (!empty($tmpobjectkey)) {
		$constforval = 'TAKEPOSRECEIPTCUSTOMIZER_'.strtoupper($tmpobjectkey).'_ADDON_PDF';
		dolibarr_del_const($db, $constforval, $conf->entity);
	}
}



/*
 * View
 */


$form = new Form($db);

$help_url = '';
$page_name = "TakeposReceiptCustomizerSetup";

llxHeader('', $langs->trans($page_name), $help_url);

// Subheader
$linkback = '<a href="'.($backtopage ? $backtopage : DOL_URL_ROOT.'/admin/modules.php?restore_lastsearch_values=1').'">'.$langs->trans("BackToModuleList").'</a>';

print load_fiche_titre($langs->trans($page_name), $linkback, 'title_setup');

// Configuration header
$head = takeposreceiptcustomizerAdminPrepareHead();
print dol_get_fiche_head($head, 'settings', $langs->trans($page_name), -1, "takeposreceiptcustomizer@takeposreceiptcustomizer");


?>




<script>
$(document).ready(function(){
    $("#companyname").on('keyup', function(){
        var matchvalue = $(this).val(); // this.value
		//alert(matchvalue);
		//alert ('../receipt.php?id=1&companyname='+matchvalue);
		document.getElementById('iframe').src='../receipt.php?id=1&companyname='+matchvalue;
        /*$.ajax({ 
            url: 'matchedit-data.php',
            data: { matchvalue: matchvalue },
            type: 'post'
        }).done(function(responseData) {
            console.log('Done: ', responseData);
        }).fail(function() {
            console.log('Failed');
        });*/
    });
});
</script>


<div style="width: 50%; float:left;background-color:#606060">
<center><br>
<iframe id="iframe" allowtransparency="true" style="background: #FFFFFF;" src="../receipt.php?id=1" width="80%" height="600"></iframe>
</center>
</div> <div style="width: 45%; float:right">
<center>
<b>Customize your receipt:</b>
</center><br>
Show logo
<?php print ajax_constantonoff("TAKEPOS_SHOW_LOGO_RECEIPT", array(), $conf->entity, 0, 0, 1, 0);
if ($conf->global->TAKEPOS_SHOW_LOGO_RECEIPT){
	print "<br>Width: <input type='number' id='width' name='width' min='1' max='500'>";
	print "Height: <input type='number' id='height' name='height' min='1' max='500'>";
}

print "<br>Company name: <input type='text' id='companyname' name='companyname' value='".$conf->global->TAKEPOS_RECEIPT_COMPANY_NAME."'>";
?>
</div>

<?php

//print '<center><iframe src="../receipt.php?id='.$id.'" width="40%" height="600"></iframe></center>';


$moduledir = 'takeposreceiptcustomizer';
$myTmpObjects = array();
$myTmpObjects['MyObject'] = array('includerefgeneration'=>0, 'includedocgeneration'=>0);






// Page end
print dol_get_fiche_end();

llxFooter();
$db->close();
